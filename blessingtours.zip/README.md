# Blessing Tours (blessingtours.pp)
A global tourism web application showcasing tourism sites, maps, photo gallery, guide requests, and bookings.

**Developer:** izabayoblessing

## Deployment
This project can be deployed on **GitHub Pages** or any static site host.

### How to deploy on GitHub Pages:
1. Upload all files to a repository named `blessingtours.pp`
2. Enable GitHub Pages from the repository settings
3. Site will be live at `https://YOUR-USERNAME.github.io/blessingtours.pp/`
